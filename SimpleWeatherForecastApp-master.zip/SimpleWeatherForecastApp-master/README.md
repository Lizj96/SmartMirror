# SimpleWeatherForecastApp
<img width="1100" height="550" src = "https://github.com/Onaeem26/SimpleWeatherForecastApp/blob/master/weatherapppic.png"></a>
