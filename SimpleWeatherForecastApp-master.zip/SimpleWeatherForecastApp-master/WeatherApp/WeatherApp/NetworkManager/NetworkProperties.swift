//
//  NetworkProperties.swift
//  WeatherApp
//
//  Created by Muhammad Osama Naeem on 3/28/20.
//  Copyright © 2020 Muhammad Osama Naeem. All rights reserved.
//

import UIKit

struct NetworkProperties {
    static let API_KEY = "5aa8d384afe4769c566762d5e85249ba"
}
